<?php
namespace Core\Database;


// Useful class database when implementing any database other than MySQL.
class Database{
}