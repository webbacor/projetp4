<?php

namespace App\Entity;

use Core\Entity\Entity;

//classes useful when implementing any database other than MySQL.
// Extends adds an authentication check 

class UserEntity Extends Entity {

}
