<head>

     <meta charset="utf-8 ">
     <meta name="description" content="billet simple pour l'Alaska" />
    <title>J Forteroche</title>
  

    
    
    <link rel="shortcut icon" href="img/favicon.png" />
    <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet" />
    <link href="css/alaska.css" rel="stylesheet" />
    <link rel="stylesheet" type="text/css" href="css/style.css"/>
    <link rel="stylesheet" type="text/css" href="css/alaska.css"/>
    
   

  <!-- adjust the layout to screen sizes / resolutions-->
    <meta name="viewport" content="width=device-width, initial-scale=1"/>  
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
       
<!--to optimize referencing-->
    <meta name="keywords" content="billet simple pour l'Alaska, Jean Forteroche" />
    <meta name="author" content="Jean Forteroche" />
    
 <!-- OpenGraph (to optimize the referencing) FACEBOOK-->
    <meta property="og:title" content="billet simple pour Alaska Jean Forteroche"/>
    <meta property="og:type" content="website"/>
    <meta property="og:description" content="billet simple pour Alaska Jean Forteroche, ecrivain, blog, commentaires" />
    <meta property="og:url" content=""/>
    <meta property="og:image" content=""/>
   
 <!-- OpenGraph (to optimize the referencing) TWITTER -->
      <meta name=”twitter:card” content="summary" />
      <meta name=”twitter:site” content="" />
      <meta name=”twitter:title” content="billet simple pour Alaska Jean Forteroche" />
      <meta name=”twitter:description” content="billet simple pour Alaska Jean Forteroche, ecrivain, blog, commentaires"  />
      <meta name=”twitter:image” content="" />

    <script src='lib/tinymce/tinymce.min.js'></script>
    

    <script>
        tinymce.init({
            selector: '#tinytextarea',
            language: 'fr_FR',
            height: 500,
            menubar: false,
            plugins: [
                'advlist autolink lists link image charmap print preview anchor',
                'searchreplace visualblocks code fullscreen',
                'insertdatetime media table contextmenu paste code textcolor colorpicker '
            ],
            toolbar: 'undo redo | insert | styleselect | bold italic | forecolor  | alignleft aligncenter alignright alignjustify' +
            ' | bullist numlist outdent indent | link image'
        });
    </script>

    
 
</head>



 