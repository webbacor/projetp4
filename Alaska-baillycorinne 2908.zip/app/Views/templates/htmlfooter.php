<footer>
       
    <div class="ecrivain">
       <img src="img/ecrivain.jpg" alt="ecrivain" >

       <div histoire> <p>

             Mon Roman en ligne<br/>

             Bienvenue sur le site de mon roman en ligne, c'est un nouveau concept que je mets en pratique, je posterai à intervales réguliers les épisodes de mon nouveau roman intitulé "Billet simple pour l'Alaska".<br/>

             J'espère que ce concept et son contenu vous plaîront, n'hésitez pas à laisser vos avis et réactions en commentaires,vous pouvez m'envoyer également un message via <a href=mailto:web.bacor@gmail>JForteroche@gmail.com</a>
             <br/>Bonne lecture et merci de l'interêt porté à mon roman.<br/></p>
            <br/>

        </div>
  
    </div>

    <div class="sigNature">
                <img src="img/xl_livre.png" alt="livre footer"> <img src="img/signature.png" alt="signature"/> 
    </div>
        <br/>
        <button data-toggle="modal" href="#infos" class="btn btn-primary">*    Mentions Légales      *</button>

   
        <?php 
        require '../web/mentions.php';
        ?>

        <button data-toggle="modal" href="#infop" class="btn btn-primary">*Politique de confidentilité*</button>

      <?php 
        require '../web/pconfid.php';
        ?>
        


  <dir class= "reseauxs">
    <a href="https://www.facebook.com/"><img src="img/Noir/noir-facebook.png" alt="facebook" ></a>
    <a href="https://twitter.com/login?lang=fr"><img src="img/Noir/noir-twitter.png" alt="twitter" ></a>
    <a href="http://www.hellocoton.fr/connexion"><img src="img/Noir/noir-hellocoton.png" alt="hellocoton" ></a>
    <a href="https://www.instagram.com/accounts/login/?hl=fr"><img src="img/Noir/noir-instagram.png" alt="instagram" ></a>
    <a href="https://www.pinterest.fr/login/"><img src="img/Noir/noir-pinterest.png" alt="pinterest" ></a>
    <br/>
</dir>

</footer>