<?php
//
return array(
    "db_user" => "dbo750395619",    
    "db_pass" => "AlaskaP4*",
    "db_host" => "db750395619.db.1and1.com",
    "db_name" => "db750395619"
);

