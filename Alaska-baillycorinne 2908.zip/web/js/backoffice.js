// demande une confirmation avant de supprimer un enregistrement.
function deleteConfirm(){
    return confirm("Voulez vous supprimer définitivement cet enregistrement?");
}

